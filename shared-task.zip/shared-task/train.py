import make_golden
from make_golden import *
from evaluation import *
import random
import numpy as np
from copy import deepcopy

import importlib
importlib.reload(make_golden)

class NaiveBayes():

    def __init__(self):
        self.train_root = {}
        self.train_negative = {}
        self.alpha = 0.000000001
        self.min_word_len = 2
        self.max_word_len = 15
        self.total_root_ngrams = [0 for _ in range(self.max_word_len)]
        self.total_negative_ngrams = [0 for _ in range(self.max_word_len)]
        self.total_root_words = 0
        self.total_negative_words = 0
        
    def generate_ngrams(self, word, n):
        if n <= 0 or n > len(word):
            return None
            # return "n must be greater than 0 and less or equal to the length of the word"
        
        ngrams = [word[i:i+n] for i in range(len(word) - n + 1)]
        return ngrams

    def train(self, data):
        for idx, item in enumerate(data):
            lemma = item['lemma']
            root = item['isRoot']

            if root:
                self.total_root_words += 1
            else: 
                self.total_negative_words += 1

            ngrams = [self.generate_ngrams(lemma, i) for i in range(self.min_word_len, self.max_word_len)]

            for n, grams in zip(range(2, self.max_word_len), ngrams):
                if grams is None: continue
                for gram in grams:
                    if root:
                        self.total_root_ngrams[n] += 1
                        if gram in self.train_root:
                            self.train_root[gram] += 1
                        else:
                            self.train_root[gram] = self.alpha + 1
                        if gram not in self.train_negative:
                            self.train_negative[gram] = self.alpha
                            self.total_negative_ngrams[n] += 1
                    else:
                        self.total_negative_ngrams[n] += 1
                        if gram in self.train_negative:
                            self.train_negative[gram] += 1
                        else:
                            self.train_negative[gram] = self.alpha + 1
                        if gram not in self.train_root:
                            self.train_root[gram] = self.alpha
                            self.total_root_ngrams[n] += 1

    def evaluate(self, lemma, naive=False):
        if naive:
            return False
        
        initial_root = self.total_root_words / (self.total_root_words + self.total_negative_words)
        initial_negative = self.total_negative_words / (self.total_root_words + self.total_negative_words)

        P_root_iter = initial_root
        P_negative_iter = initial_negative

        # print(initial_root, initial_negative)
        # print(P_root_iter, P_negative_iter)

        ngrams = [self.generate_ngrams(lemma, i) for i in range(self.min_word_len, self.max_word_len)]

        for n, grams in zip(range(2, self.max_word_len), ngrams):
            if grams is None: continue
            for gram in grams:
                # print(gram)
                if gram in self.train_root and gram in self.train_negative:
                    #pravdepodobnost, ze jakykoliv 2-gram je root/negative
                    P_gram_is_root = self.total_root_ngrams[n] / (self.total_root_ngrams[n] + self.total_negative_ngrams[n])
                    P_gram_is_negative = self.total_negative_ngrams[n] / (self.total_root_ngrams[n] + self.total_negative_ngrams[n])

                    #pravdepodobnost, ze tento konkretni 2-gram je root/negative
                    P_gram_in_root = self.train_root[gram] / self.total_root_ngrams[n]
                    P_gram_in_negative = self.train_negative[gram] / self.total_negative_ngrams[n]

                    P_root = (P_gram_is_root * P_gram_in_root) / ((P_gram_is_root * P_gram_in_root) + (P_gram_is_negative * P_gram_in_negative))
                    P_negative = (P_gram_is_negative * P_gram_in_negative) / ((P_gram_is_root * P_gram_in_root) + (P_gram_is_negative * P_gram_in_negative))

                    # print(P_root, P_negative)
                    
                    P_root_iter *= P_root
                    P_negative_iter *= P_negative

        return P_root_iter >= P_negative_iter
        print(P_root_iter, P_negative_iter)

    def test(self, data, naive=False):
        y_count = 0
        for item in data:
            item['isRoot'] = False
            prediction = self.evaluate(item['lemma'], naive)
            if prediction:
                y_count += 1
                # print(item['lemma'])
                item['isRoot'] = True
            else:
                item['isRoot'] = False
        
        # print(y_count)
        if naive:
            write_dataset("prediction_naive.tsv", data)
        else:
            write_dataset("prediction.tsv", data)
        return data

# def create_dataset():
#     data_golden = read_dataset_lazy("golden.tsv")
#     data_1000 = read_dataset_lazy("derinet_1000_annotated.tsv")
#     data_golden.extend(data_1000)
#     write_dataset("dataset.tsv", data_golden)
#     return data_golden

def single_run(dataset, seed=None):
    def convert(data):
        y = []
        for row in data:
            y.append(1 if row['isRoot'] == True else 0)
        return y
    
    if seed is not None:
        random.seed(seed)
    else:
        random.seed()

    dataset_len = len(dataset)    
    # print(dataset_len)

    train = random.sample(range(dataset_len), dataset_len//2)
    test = [n for n in range(dataset_len)]
    test = list(set(test) - set(train))

    d = np.array(deepcopy(dataset))

    dataset_truth = deepcopy(dataset)
    d_truth = np.array(dataset_truth)
    truth = list(d_truth[test])
    write_dataset("truth.tsv", truth)

    classificator = NaiveBayes()
    classificator.train(list(d[train]))
    prediction = classificator.test(list(d[test]))

    dataset_naive = deepcopy(dataset)
    d_naive = np.array(dataset_naive)
    prediction_naive = classificator.test(d_naive[test], naive=True)

    return [accuracy(convert(truth), convert(prediction)), accuracy(convert(truth), convert(prediction_naive))]

if __name__ == "__main__":
    dataset = read_dataset("dataset.tsv")

    X = [single_run(dataset, s) for s in range(50)]
    means = np.mean(np.array(X), axis=0)

    print("average accuracy of naive bayes: " + str(means[0]))
    print("average accuracy of baseline: " + str(means[1]))








    