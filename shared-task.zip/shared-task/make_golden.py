import csv

ANNOTATED_DATASETS = {
    "MT": "derinet_hand_anot_roots_MT.tsv",
    "MO": "derinet_hand_anot_roots_MO.tsv",
    "MP": "derinet_hand_anot_roots_MP.tsv",
}


def read_dataset(filename):
    """Reads the annotated dataset into a list of responses of the shape {"lemma", "isRoot"}"""
    with open(filename, encoding="utf-8") as csv_file:
        reader = csv.DictReader(csv_file, delimiter="\t")
        data = []
        for row in reader:
            data.append(
                {
                    "lemma": row["#lemma"].strip(),
                    "isRoot": row["#is true root [y/n]"] == "y",
                    "id": row["#derinet id"],
                }
            )
        return data

def read_dataset_lazy(filename):
    """Reads the annotated dataset into a list of responses of the shape {"lemma", "isRoot"}"""
    lines = None
    with open(filename, encoding="utf-8") as csv_file:
        lines = csv_file.readlines()

    data = []

    for line in lines[1:]:
        row = line.split()
        # print(row)
        if(len(row) < 3): break
        data.append({
            "lemma": row[1],
            "isRoot": row[2] == "y",
            "id": int(row[0].split('.')[0])
        })

    return data

def write_dataset(filename, dataset):
    with open(filename, "w", newline="", encoding="utf-8") as csv_file:
        writer = csv.writer(csv_file, delimiter="\t")
        writer.writerow(["#derinet id", "#lemma", "#is true root [y/n]"])
        for row in dataset:
            writer.writerow([row["id"], row["lemma"], "y" if row["isRoot"] else "n"])


def read_data():
    data = []
    for key, filename in ANNOTATED_DATASETS.items():
        data.append(read_dataset(filename))
    return data


def create_golden(datasets):
    golden = []
    # print(datasets)
    for i in range(len(datasets[0])):
        golden_is_root = round(
            sum(map(lambda dataset: dataset[i]["isRoot"], datasets)) / len(datasets)
        )
        # print(golden_is_root)
        golden_id = datasets[0][i]["id"]
        golden_lemma = datasets[0][i]["lemma"]
        golden.append(
            {"id": golden_id, "lemma": golden_lemma, "isRoot": golden_is_root}
        )

    return golden


def main():
    datasets = read_data()
    golden = create_golden(datasets)
    write_dataset("golden.tsv", golden)


# main()
