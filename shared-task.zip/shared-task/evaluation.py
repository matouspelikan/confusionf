#!/usr/bin/env python3

import csv

smooth_factor = 0.000001

def accuracy(gold, estimate):
    all = 0
    correct = 0
    for g, e in zip(gold, estimate):
        all += 1
        if g == e:
            correct += 1
    return correct / all

def _count_occurences(gold, estimate, predicate):
    return sum([predicate(g, e) for g, e in zip(gold, estimate)])


def precision(gold, estimate):
    true_positives = _count_occurences(gold, estimate, lambda g, e: g and g == e)
    all_positives = _count_occurences(gold, estimate, lambda g, e: e)
    return true_positives / (all_positives + smooth_factor)


def recall(gold, estimate):
    true_positives = _count_occurences(gold, estimate, lambda g, e: g and g == e)
    all_true = _count_occurences(gold, estimate, lambda g, e: g)
    return true_positives / (all_true + smooth_factor)


def f_measure(gold, estimate, beta=1):
    """Computes the F measure of the estimate data when compared to a golden version.
    The data should be classification of 1 and 0 (True and False also works) with the 1
    being treated as the positive.
    """
    p = precision(gold, estimate)
    r = recall(gold, estimate)

    return ((1 + beta**2) * p * r) / (beta**2 * p + r + smooth_factor)


if __name__ == "__main__":
    import argparse

    def read_dataset(filename):
        with open(filename, encoding="utf-8") as csv_file:
            reader = csv.DictReader(csv_file, delimiter="\t")
            data = []
            for row in reader:
                data.append(1 if row["#is true root [y/n]"] == "y" else 0)
            return data

    def check_positive(value):
        fvalue = float(value)
        if fvalue <= 0:
            raise argparse.ArgumentTypeError(f"{fvalue} is an invalid positive value")
        return fvalue

    parser = argparse.ArgumentParser(prog="Derinet evaluator")
    parser.add_argument("golden", help="The golden annotated data")
    parser.add_argument("predicted", help="Your predicted data")
    parser.add_argument(
        "-b", "--beta", required=False, default=1.0, type=check_positive
    )

    args = parser.parse_args()
    print(args)

    estimate = read_dataset(args.predicted)

    golden = read_dataset(args.golden)

    print(f"F-{args.beta} measure: {f_measure(golden, estimate, args.beta)}")
